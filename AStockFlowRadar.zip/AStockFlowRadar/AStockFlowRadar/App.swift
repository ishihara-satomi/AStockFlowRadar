import SwiftUI

@main
struct AStockFlowRadarApp: App {
    var body: some Scene {
        WindowGroup { DashboardView() }
    }
}
