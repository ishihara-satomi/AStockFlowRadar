import Foundation

struct MarketIndex: Identifiable, Codable {
    let id: String
    let name: String
    let value: Double
    let changePercent: Double
}

struct SectorFlow: Identifiable, Codable {
    let id: String
    let name: String
    let changePercent: Double
    let inflowYi: Double
    let outflowYi: Double
    var netFlowYi: Double { inflowYi - outflowYi }
}

struct StockSignal: Identifiable, Codable {
    let id: String
    let name: String
    let code: String
    let changePercent: Double
    let volumeRatio: Double
    let turnoverYi: Double
}

struct MarketSnapshot: Codable {
    let updatedAt: Date
    let isDemo: Bool
    let indices: [MarketIndex]
    let turnoverYi: Double
    let advancing: Int
    let declining: Int
    let totalNetFlowYi: Double
    let sectors: [SectorFlow]
    let volumeLeaders: [StockSignal]
}
