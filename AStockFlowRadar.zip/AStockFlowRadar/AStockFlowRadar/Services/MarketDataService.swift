import Foundation

protocol MarketDataService {
    func fetchSnapshot() async throws -> MarketSnapshot
}

/// Demo-only provider. Replace with an authorized backend provider before publishing real market data.
struct DemoMarketDataService: MarketDataService {
    func fetchSnapshot() async throws -> MarketSnapshot {
        try await Task.sleep(for: .milliseconds(250))
        let sectors = [
            SectorFlow(id: "electronics", name: "电子", changePercent: 1.82, inflowYi: 128.6, outflowYi: 91.3),
            SectorFlow(id: "power", name: "电力设备", changePercent: 1.24, inflowYi: 102.4, outflowYi: 79.1),
            SectorFlow(id: "computer", name: "计算机", changePercent: 0.76, inflowYi: 86.2, outflowYi: 72.7),
            SectorFlow(id: "medicine", name: "医药生物", changePercent: -0.42, inflowYi: 54.3, outflowYi: 69.8),
            SectorFlow(id: "realestate", name: "房地产", changePercent: -1.16, inflowYi: 42.8, outflowYi: 67.5),
            SectorFlow(id: "bank", name: "银行", changePercent: 0.18, inflowYi: 73.2, outflowYi: 68.6),
            SectorFlow(id: "auto", name: "汽车", changePercent: 0.91, inflowYi: 64.8, outflowYi: 51.9)
        ]
        let stocks = [
            StockSignal(id: "300750", name: "宁德时代", code: "300750", changePercent: 2.36, volumeRatio: 2.82, turnoverYi: 43.7),
            StockSignal(id: "002594", name: "比亚迪", code: "002594", changePercent: 1.58, volumeRatio: 2.34, turnoverYi: 28.1),
            StockSignal(id: "600519", name: "贵州茅台", code: "600519", changePercent: -0.72, volumeRatio: 1.96, turnoverYi: 21.6),
            StockSignal(id: "000725", name: "京东方A", code: "000725", changePercent: 3.14, volumeRatio: 3.71, turnoverYi: 18.9),
            StockSignal(id: "601899", name: "紫金矿业", code: "601899", changePercent: 1.03, volumeRatio: 2.11, turnoverYi: 17.4)
        ]
        return MarketSnapshot(
            updatedAt: .now, isDemo: true,
            indices: [
                MarketIndex(id: "sh", name: "上证指数", value: 3286.42, changePercent: 0.63),
                MarketIndex(id: "sz", name: "深证成指", value: 10482.16, changePercent: 0.91),
                MarketIndex(id: "cy", name: "创业板指", value: 2186.37, changePercent: 1.27)
            ],
            turnoverYi: 8264.0, advancing: 2846, declining: 1973,
            totalNetFlowYi: 36.8, sectors: sectors, volumeLeaders: stocks
        )
    }
}
