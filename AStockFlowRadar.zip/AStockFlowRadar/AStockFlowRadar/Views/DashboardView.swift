import SwiftUI

@MainActor
final class DashboardModel: ObservableObject {
    @Published var snapshot: MarketSnapshot?
    @Published var isRefreshing = false
    @Published var errorMessage: String?
    @Published var refreshSeconds = 3
    @Published var selectedTab = 0
    private let service: MarketDataService = DemoMarketDataService()
    private var refreshTask: Task<Void, Never>?

    func refresh() async {
        guard !isRefreshing else { return }
        isRefreshing = true
        defer { isRefreshing = false }
        do { snapshot = try await service.fetchSnapshot(); errorMessage = nil }
        catch { errorMessage = "行情更新失败，请检查网络或数据服务配置。" }
    }

    func startAutoRefresh() {
        refreshTask?.cancel()
        refreshTask = Task {
            while !Task.isCancelled {
                await refresh()
                try? await Task.sleep(for: .seconds(refreshSeconds))
            }
        }
    }

    deinit { refreshTask?.cancel() }
}

struct DashboardView: View {
    @StateObject private var model = DashboardModel()
    private let bg = Color(red: 0.055, green: 0.075, blue: 0.105)
    private let panel = Color(red: 0.105, green: 0.13, blue: 0.17)

    var body: some View {
        ZStack {
            bg.ignoresSafeArea()
            VStack(spacing: 0) {
                header
                if let s = model.snapshot {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 18) {
                            if model.selectedTab == 0 {
                                demoNotice(s)
                                indexStrip(s)
                                marketStats(s)
                                sectorSection(s)
                                volumeSection(s)
                                footer(s)
                            } else if model.selectedTab == 1 {
                                demoNotice(s)
                                sectorSection(s)
                                Text("资金流向口径因数据供应商而异；当前为演示数据。")
                                    .font(.system(size: 11)).foregroundStyle(.secondary)
                            } else if model.selectedTab == 2 {
                                demoNotice(s)
                                volumeSection(s)
                                Text("量比通常用于比较当前成交活跃度与历史同期水平，具体计算口径以数据源为准。")
                                    .font(.system(size: 11)).foregroundStyle(.secondary)
                            } else {
                                settingsSection(s)
                            }
                        }.padding(.horizontal, 16).padding(.top, 12).padding(.bottom, 24)
                    }
                } else {
                    ProgressView("正在加载演示行情…").tint(.white).foregroundStyle(.white).frame(maxWidth: .infinity, maxHeight: .infinity)
                }
                tabBar
            }
        }
        .preferredColorScheme(.dark)
        .task { await model.refresh(); model.startAutoRefresh() }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                Text("A股资金雷达").font(.system(size: 24, weight: .bold))
                Text("MARKET FLOW MONITOR").font(.system(size: 9, weight: .semibold, design: .rounded)).tracking(1.4).foregroundStyle(.secondary)
            }
            Spacer()
            Button { Task { await model.refresh() } } label: {
                Image(systemName: "arrow.clockwise").font(.system(size: 16, weight: .semibold)).padding(11).background(panel, in: Circle())
            }.accessibilityLabel("刷新行情")
        }.foregroundStyle(.white).padding(.horizontal, 18).padding(.top, 10).padding(.bottom, 12)
    }

    private func demoNotice(_ s: MarketSnapshot) -> some View {
        HStack(alignment: .top, spacing: 9) {
            Image(systemName: "info.circle.fill").foregroundStyle(.yellow)
            VStack(alignment: .leading, spacing: 3) {
                Text(s.isDemo ? "演示模式 · 非实时行情" : "实时行情").font(.system(size: 13, weight: .bold))
                Text(s.isDemo ? "当前数字为模拟数据，仅用于预览界面。接入授权数据源前，请勿用于投资决策。" : "数据时间：\(s.updatedAt.formatted(date: .omitted, time: .standard))")
                    .font(.system(size: 11)).foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
        }.padding(12).background(Color.yellow.opacity(0.09), in: RoundedRectangle(cornerRadius: 12)).overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.yellow.opacity(0.2), lineWidth: 1))
    }

    private func indexStrip(_ s: MarketSnapshot) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack { Text("大盘指数").font(.system(size: 16, weight: .bold)); Spacer(); Text("模拟行情").font(.system(size: 10)).foregroundStyle(.secondary) }
            HStack(spacing: 8) {
                ForEach(s.indices) { item in
                    VStack(alignment: .leading, spacing: 7) {
                        Text(item.name).font(.system(size: 11)).foregroundStyle(.secondary).lineLimit(1)
                        Text(item.value, format: .number.precision(.fractionLength(2))).font(.system(size: 17, weight: .bold, design: .rounded)).monospacedDigit()
                        change(item.changePercent)
                    }.frame(maxWidth: .infinity, alignment: .leading).padding(10).background(panel, in: RoundedRectangle(cornerRadius: 12))
                }
            }
        }.foregroundStyle(.white)
    }

    private func marketStats(_ s: MarketSnapshot) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("资金与成交概览").font(.system(size: 16, weight: .bold)).foregroundStyle(.white)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 9) {
                statCard("两市成交额", value: String(format: "%.0f 亿", s.turnoverYi), subtitle: "当日累计", color: .white)
                statCard("全市场净流向", value: signed(s.totalNetFlowYi), subtitle: "资金口径需以数据源为准", color: s.totalNetFlowYi >= 0 ? .red : .green)
                statCard("上涨家数", value: "\(s.advancing)", subtitle: "全市场股票", color: .red)
                statCard("下跌家数", value: "\(s.declining)", subtitle: "全市场股票", color: .green)
            }
        }
    }

    private func statCard(_ title: String, value: String, subtitle: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title).font(.system(size: 12)).foregroundStyle(.secondary)
            Text(value).font(.system(size: 21, weight: .bold, design: .rounded)).foregroundStyle(color).minimumScaleFactor(0.7).lineLimit(1)
            Text(subtitle).font(.system(size: 10)).foregroundStyle(.secondary).lineLimit(1)
        }.frame(maxWidth: .infinity, alignment: .leading).padding(13).background(panel, in: RoundedRectangle(cornerRadius: 13))
    }

    private func sectorSection(_ s: MarketSnapshot) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack { Text("行业板块资金").font(.system(size: 16, weight: .bold)); Spacer(); Text("按净流入排序").font(.system(size: 10)).foregroundStyle(.secondary) }
            HStack {
                Text("行业").frame(maxWidth: .infinity, alignment: .leading)
                Text("涨跌幅").frame(width: 64, alignment: .trailing)
                Text("净流入(亿)").frame(width: 86, alignment: .trailing)
            }.font(.system(size: 10)).foregroundStyle(.secondary)
            ForEach(s.sectors.sorted { $0.netFlowYi > $1.netFlowYi }) { item in
                HStack(spacing: 8) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(item.name).font(.system(size: 13, weight: .medium))
                        GeometryReader { geo in
                            ZStack(alignment: .leading) {
                                Capsule().fill(Color.white.opacity(0.07))
                                Capsule().fill(item.netFlowYi >= 0 ? Color.red.opacity(0.85) : Color.green.opacity(0.85)).frame(width: geo.size.width * min(abs(item.netFlowYi) / 50, 1))
                            }
                        }.frame(height: 4)
                    }.frame(maxWidth: .infinity, alignment: .leading)
                    change(item.changePercent).frame(width: 64, alignment: .trailing)
                    Text(signed(item.netFlowYi)).font(.system(size: 12, weight: .semibold, design: .rounded)).foregroundStyle(item.netFlowYi >= 0 ? .red : .green).frame(width: 86, alignment: .trailing).monospacedDigit()
                }.padding(.vertical, 5)
            }
        }.foregroundStyle(.white).padding(14).background(panel.opacity(0.7), in: RoundedRectangle(cornerRadius: 14))
    }

    private func volumeSection(_ s: MarketSnapshot) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack { Text("量比异动观察").font(.system(size: 16, weight: .bold)); Spacer(); Text("演示榜单").font(.system(size: 10)).foregroundStyle(.secondary) }
            ForEach(s.volumeLeaders.sorted { $0.volumeRatio > $1.volumeRatio }) { stock in
                HStack(spacing: 10) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(stock.name).font(.system(size: 13, weight: .semibold))
                        Text(stock.code).font(.system(size: 10, design: .monospaced)).foregroundStyle(.secondary)
                    }.frame(maxWidth: .infinity, alignment: .leading)
                    Text(String(format: "%.2fx", stock.volumeRatio)).font(.system(size: 13, weight: .bold, design: .rounded)).foregroundStyle(stock.volumeRatio >= 2 ? .orange : .white).frame(width: 58, alignment: .trailing)
                    change(stock.changePercent).frame(width: 68, alignment: .trailing)
                    Text(String(format: "%.1f亿", stock.turnoverYi)).font(.system(size: 11, design: .rounded)).foregroundStyle(.secondary).frame(width: 55, alignment: .trailing)
                }.padding(.vertical, 4)
            }
        }.foregroundStyle(.white).padding(14).background(panel.opacity(0.7), in: RoundedRectangle(cornerRadius: 14))
    }


    private func settingsSection(_ s: MarketSnapshot) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("监控设置").font(.system(size: 20, weight: .bold))
            VStack(alignment: .leading, spacing: 10) {
                Text("自动刷新间隔").font(.system(size: 14, weight: .semibold))
                Text("较短的间隔不代表数据源每次都会返回新行情。请遵守数据服务商的频率限制。")
                    .font(.system(size: 11)).foregroundStyle(.secondary)
                HStack(spacing: 8) {
                    ForEach([1, 3, 5, 10], id: \.self) { seconds in
                        Button {
                            model.refreshSeconds = seconds
                            model.startAutoRefresh()
                        } label: {
                            Text("\(seconds) 秒")
                                .font(.system(size: 13, weight: .semibold))
                                .frame(maxWidth: .infinity).padding(.vertical, 11)
                                .background(model.refreshSeconds == seconds ? Color.cyan.opacity(0.22) : panel, in: RoundedRectangle(cornerRadius: 10))
                                .overlay(RoundedRectangle(cornerRadius: 10).stroke(model.refreshSeconds == seconds ? Color.cyan : Color.clear, lineWidth: 1))
                        }.buttonStyle(.plain)
                    }
                }
            }.padding(14).background(panel, in: RoundedRectangle(cornerRadius: 14))
            VStack(alignment: .leading, spacing: 9) {
                Text("数据状态").font(.system(size: 14, weight: .semibold))
                Label(s.isDemo ? "演示数据，尚未接入实时行情" : "已接收数据", systemImage: s.isDemo ? "exclamationmark.triangle.fill" : "checkmark.circle.fill")
                    .font(.system(size: 12)).foregroundStyle(s.isDemo ? .yellow : .green)
                Text("最近刷新：\(s.updatedAt.formatted(date: .abbreviated, time: .standard))")
                    .font(.system(size: 12)).foregroundStyle(.secondary)
                Button { Task { await model.refresh() } } label: {
                    Label("立即刷新", systemImage: "arrow.clockwise")
                        .font(.system(size: 13, weight: .semibold)).frame(maxWidth: .infinity).padding(12)
                        .background(Color.cyan.opacity(0.15), in: RoundedRectangle(cornerRadius: 10))
                }.buttonStyle(.plain)
            }.padding(14).background(panel, in: RoundedRectangle(cornerRadius: 14))
            Text("重要提示：本项目当前使用模拟行情，不提供真实买卖信号。接入真实行情前，不应将其用于投资决策。")
                .font(.system(size: 11)).foregroundStyle(.secondary)
        }.foregroundStyle(.white)
    }

    private func footer(_ s: MarketSnapshot) -> some View {
        VStack(spacing: 5) {
            Text("刷新间隔：\(model.refreshSeconds) 秒 · 最近刷新：\(s.updatedAt.formatted(date: .omitted, time: .standard))")
            Text("资金流向为数据源计算口径，可能不代表真实净买入。仅供信息展示，不构成投资建议。")
        }.font(.system(size: 10)).foregroundStyle(.secondary).frame(maxWidth: .infinity).multilineTextAlignment(.center).padding(.top, 4)
    }

    private var tabBar: some View {
        HStack {
            tabItem("chart.xyaxis.line", title: "总览", index: 0)
            tabItem("square.grid.2x2", title: "板块", index: 1)
            tabItem("waveform.path.ecg", title: "量比", index: 2)
            tabItem("slider.horizontal.3", title: "设置", index: 3)
        }.padding(.top, 11).padding(.bottom, 8).background(bg.opacity(0.98)).overlay(alignment: .top) { Rectangle().fill(Color.white.opacity(0.08)).frame(height: 1) }
    }

    private func tabItem(_ symbol: String, title: String, index: Int) -> some View {
        Button { model.selectedTab = index } label: {
            VStack(spacing: 5) { Image(systemName: symbol).font(.system(size: 17)); Text(title).font(.system(size: 10)) }
                .foregroundStyle(model.selectedTab == index ? Color.cyan : Color.gray).frame(maxWidth: .infinity)
        }
    }

    private func change(_ value: Double) -> some View {
        Text(String(format: "%@%.2f%%", value > 0 ? "+" : "", value)).font(.system(size: 11, weight: .semibold, design: .rounded)).foregroundStyle(value >= 0 ? .red : .green).monospacedDigit()
    }
    private func signed(_ value: Double) -> String { String(format: "%@%.1f", value > 0 ? "+" : "", value) }
}
